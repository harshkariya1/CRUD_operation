const express = require('express');
const UserController = require('../controllers/userController')
const router = express();

require('../model')

router.get('/', (req, res) => {
    res.send("Hello")
})

router.get('/users', UserController.fetchUsers)

module.exports = router
